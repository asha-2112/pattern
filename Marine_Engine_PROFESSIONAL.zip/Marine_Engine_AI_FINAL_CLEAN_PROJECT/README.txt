MARINE ENGINE AI - FINAL CLEAN LSTM PROJECT

INPUT
-----
Only one input is required:
data/marine_engine_fault_dataset.csv

RUN
---
pip install -r requirements.txt
python train_final.py

PIPELINE
--------
1. Load and validate 18 raw sensor parameters.
2. Chronological 70/15/15 split.
3. Test 10, 20 and 30 second LSTM sequence lengths.
4. Select the sequence length using validation Macro F1.
5. Evaluate the selected 8-class LSTM.
6. Extract the 32-dimensional learned representation.
7. Discover validated behavioural patterns for Faults 1-3 only (K=2,3,2).
8. Perform descriptive contributing-parameter analysis for Faults 4-7.
9. Generate a clean human-readable Fault Class Reference in TXT and Excel format.
10. Generate timestamp-level predicted fault occurrences.

MAIN OUTPUTS
------------
outputs/classification_report.csv
outputs/confusion_matrix.csv
outputs/discovered_patterns.csv
outputs/contributing_parameters.csv
outputs/FAULT_CLASS_REFERENCE.txt
outputs/FAULT_CLASS_REFERENCE.csv
outputs/FINAL_RESEARCH_REPORT.txt

The Excel reference contains four sheets:
1. Fault Class Reference
2. Behavioural Patterns
3. Contributing Parameters
4. Viva Summary

INTERMEDIATE OUTPUTS
--------------------
All detailed/reproducibility files are written automatically to analysis_outputs/.
They are not required as inputs and are regenerated on every run.

MODEL
-----
Single 8-class LSTM, 18 raw sensors, no manual fault signatures, no class weights.
The selected sequence length is determined from validation Macro F1.

FAULT LABEL MEANING
-------------------
Fault 0 is Normal.
Faults 1-7 are dataset-defined fault classes.
The supplied dataset/documentation does not provide official physical names for Faults 1-7.
The project therefore reports data-derived behavioural descriptions rather than inventing
physical fault names.

TERMINOLOGY
-----------
Use: dataset-defined fault class, behavioural pattern, contributing parameter, fault occurrence.
Avoid: proven physical fault subtype, proven root cause, physical event detection accuracy.

NOTE
----
The clean Excel reference requires openpyxl. If openpyxl is unavailable, the pipeline still
creates FAULT_CLASS_REFERENCE.txt and all original CSV/TXT outputs, and continues without
failing solely because of the optional Excel report.
